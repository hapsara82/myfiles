import tls from "tls";

interface ProxyStruct {
  address: string;
  port: number;
  country: string;
  org: string;
}

interface ProxyTestResult {
  error: boolean;
  message?: string;
  result?: {
    proxy: string;
    proxyip: boolean;
    ip: string;
    port: number;
    delay: number;
    country: string;
    asOrganization: string;
  };
}

const IP_RESOLVER = "ip.xior.workers.dev";
const CONCURRENCY = 99;
const TIMEOUT = 5000;

let myGeoIp: string | null = null;

async function sendRequest(host: string, path: string, proxyHost?: string, proxyPort?: number) {
  return new Promise<string>((resolve, reject) => {
    const socket = tls.connect(
      { host: proxyHost || host, port: proxyPort || 443, servername: host },
      () => {
        socket.write(
          `GET ${path} HTTP/1.1\r\nHost: ${host}\r\nUser-Agent: Mozilla/5.0\r\nConnection: close\r\n\r\n`
        );
      }
    );

    let response = "";
    const timer = setTimeout(() => {
      socket.destroy();
      reject(new Error("socket timeout"));
    }, TIMEOUT);

    socket.on("data", (data) => (response += data.toString()));
    socket.on("end", () => {
      clearTimeout(timer);
      resolve(response.split("\r\n\r\n")[1] || "");
    });
    socket.on("error", reject);
  });
}

async function checkProxy(address: string, port: number): Promise<ProxyTestResult> {
  try {
    const start = Date.now();
    const [proxyData, localData] = await Promise.all([
      sendRequest(IP_RESOLVER, "/", address, port),
      myGeoIp || sendRequest(IP_RESOLVER, "/"),
    ]);

    if (!myGeoIp) myGeoIp = localData;

    const proxy = JSON.parse(proxyData);
    const local = JSON.parse(myGeoIp);

    if (proxy.ip === local.ip) return { error: true };

    return {
      error: false,
      result: { ...proxy, proxy: address, port, proxyip: true, delay: Date.now() - start },
    };
  } catch (error: any) {
    return { error: true, message: error.message };
  }
}

(async () => {
  const start = Date.now();
  const rawProxies = await Bun.file("./test.txt").text();

  const proxyList: ProxyStruct[] = rawProxies
    .split("\n")
    .filter(Boolean)
    .map((line) => {
      const [address, port, country, org] = line.split(",");
      return { address, port: parseInt(port), country, org };
    });

  const seen = new Set<string>();
  const active: string[] = [];
  const kvPair: Record<string, string[]> = {};
  let queue = 0;
  let saved = 0;

  const sortByCountry = (a: string, b: string) => a.split(",")[2].localeCompare(b.split(",")[2]);

  for (const proxy of proxyList) {
    const key = `${proxy.address}:${proxy.port}`;
    if (seen.has(key)) continue;
    seen.add(key);

    queue++;
    checkProxy(proxy.address, proxy.port)
      .then((res) => {
        if (!res.error && res.result?.proxyip && res.result.country) {
          const line = `${res.result.proxy},${res.result.port},${res.result.country},${res.result.asOrganization}`;
          active.push(line);

          if (!kvPair[res.result.country]) kvPair[res.result.country] = [];
          kvPair[res.result.country].push(`${res.result.proxy}:${res.result.port}`);

          console.log(`[${++saved}] Proxy saved`);
        }
      })
      .finally(() => queue--);

    while (queue >= CONCURRENCY) await Bun.sleep(1);
  }

  while (queue > 0) await Bun.sleep(1);

  // urutkan ok.json: country dengan jumlah proxy terbanyak dulu
  const sortedKvPair = Object.fromEntries(
    Object.entries(kvPair).sort(([, a], [, b]) => b.length - a.length)
  );

  await Bun.write("./ok.json", JSON.stringify(sortedKvPair, null, 2));
  await Bun.write("./ok.txt", active.sort(sortByCountry).join("\n"));

  console.log(`Completed in ${((Date.now() - start) / 1000).toFixed(2)}s`);
  process.exit(0);
})();
